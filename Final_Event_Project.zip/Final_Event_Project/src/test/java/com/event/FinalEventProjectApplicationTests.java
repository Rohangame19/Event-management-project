package com.event;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalEventProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
