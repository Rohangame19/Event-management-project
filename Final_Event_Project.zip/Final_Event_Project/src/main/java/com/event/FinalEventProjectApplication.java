package com.event;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalEventProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalEventProjectApplication.class, args);
	}

}
